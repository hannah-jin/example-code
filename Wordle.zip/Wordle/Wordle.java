import java.util.Scanner;
/**
 * Try to guess a five letter word. Imitating the popular game Wordle.
 *
 * @author Hannah Jin
 * @date 2/2/2022
 */
public class Wordle
{
    private final static String word = "SHARK";
    private static char[] theAlphabet = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'};
    /**
     * Main method for Wordle. Takes input and prints the alphabet and word clues. 
     */
    public static void main()
    {    
        Scanner input = new Scanner(System.in);
        int guesses = 6;
        String guess;
        System.out.println(theAlphabet);
        do{
            guess = input(guesses);
            if(!guess.equals(word))
            {
                char[] aGuess = new char[5];
                aGuess = toArray(guess);
                char[] userSolution = compareTo(aGuess);
                print(userSolution, theAlphabet);
                guesses--;
            }
            else
            {
                System.out.println("Congratulations! You got the word in " + guesses + "  tries.");
            }
        }while(guesses > 0 && !guess.equals(word));
        if(guesses == 0)
        {
            System.out.println("Sorry! You did not the the word.");
        }
    }
    
    /**
     * Asks the user for input and returns it with all capital letters
     * 
     * @param the number of guesses they have left, starting from 6
     * @return the input with all capital letters in the form of a String
     */
    public static String input(int numGuesses)
    {
        System.out.println("Make a five-letter guess (" + numGuesses + " remaining):");
        Scanner input = new Scanner(System.in);
        String capitalGuess = input.nextLine().toUpperCase();
        input.close();
        return capitalGuess;
    }

    /**
     * Converting the user's string to a character array
     * 
     * @param the user's string input
     * @return the user's input in the form of an array
     */
    public static char[] toArray(String userGuess)
    {
        char arrGuess[] = new char[userGuess.length()];
        for(int i = 0; i < userGuess.length(); i++)
        {
            arrGuess[i] = userGuess.charAt(i);
        }      
        return arrGuess;
    }
    
    /**
     * Comparing the user's input to Wordle word using a solution array and changing the alphabet
     * 
     * @param the user's input in the form of an array
     * @return the solution array with lowercase letters and underscores
     */
    public static char[] compareTo(char[] theGuess)
    {
        char solution[] = new char[5];
        for(int i = 0; i < 5; i++)
        {
            if(word.charAt(i) == theGuess[i])
            {
                solution[i] = theGuess[i];
            }
            else if(word.indexOf(theGuess[i]) > -1)
            {
                solution[i] = Character.toLowerCase(theGuess[i]);
            }
            else
            {
                solution[i] = '_';
                for(int j = 0; j < theAlphabet.length; j++)
                {
                    if(theAlphabet[j] == theGuess[i])
                    {
                        theAlphabet[j] = '_';
                    }
                }
            }
        }
        return solution;
    }
    
    /**
     * Printing out the alphabet and solution arrays
     * 
     * @param the solutions and alphabet arrays
     */
    public static void print(char[] aSolution, char[] alphabet)
    {
        for(char character: aSolution)
        {
            System.out.print(character);
        }
        System.out.println();
        for(char letter: alphabet)
        {
            System.out.print(letter);
        }
        System.out.println();
    }
}
